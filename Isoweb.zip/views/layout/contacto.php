<section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h2 class="section-heading">Mantengámonos en contacto</h2>
                    <hr class="my-4">
                    <p class="mb-5">
                        Con esta información podemos ponernos en contacto.
                    </p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-12 col-sm-4 ml-auto text-center">
                    <div class="wrap__index">
                        <input type="text" name="your-name" value="" size="40" class="" placeholder="Nombre *">
                    </div>
                </div>
                <div class="col-12 col-sm-4 ml-auto text-center">
                    <div class="wrap__index">
                        <input type="text" name="your-name" value="" size="40" class="" placeholder="Email *">
                    </div>
                </div>
                <div class="col-12 col-sm-4 ml-auto text-center">
                    <div class="wrap__index">    
                        <input type="text" name="your-name" value="" size="40" class="" placeholder="Telefono *">
                    </div>
                </div>
            </div>
            <div class="row justify-content-center mt-4">
                <div class="col-12 col-sm-4 text-center">
                    <a class="btn btn-dark btn-xl js-scroll-trigger" href="#services">Comenzar ya!</a>
                </div>
            </div>
        </div>
    </section>