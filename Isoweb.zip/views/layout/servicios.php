<section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">A su servicio</h2>
                    <hr class="my-4">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box mt-5 mx-auto">
                        <i class="fa fa-4x fa-diamond text-primary mb-3 sr-icons"></i>
                        <h3 class="mb-3">Lorem Ipsum</h3>
                        <p class="text-muted mb-0">Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box mt-5 mx-auto">
                        <i class="fa fa-4x fa-paper-plane text-primary mb-3 sr-icons"></i>
                        <h3 class="mb-3">Lorem Ipsum</h3>
                        <p class="text-muted mb-0">Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto.!</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box mt-5 mx-auto">
                        <i class="fa fa-4x fa-newspaper-o text-primary mb-3 sr-icons"></i>
                        <h3 class="mb-3">Lorem Ipsum</h3>
                        <p class="text-muted mb-0">Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 text-center">
                    <div class="service-box mt-5 mx-auto">
                        <i class="fa fa-4x fa-heart text-primary mb-3 sr-icons"></i>
                        <h3 class="mb-3">Lorem Ipsum</h3>
                        <p class="text-muted mb-0">Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>