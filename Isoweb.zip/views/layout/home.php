
<header class="masthead text-center text-white d-flex">
    <div class="wrap__masthead">
        <div class="">
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <h1 class="text-uppercase">
                        <strong>Nuestro negocio es saber las necesidades de su negocio</strong>
                    </h1>
                    <hr>
                </div>
                <div class="col-lg-8 mx-auto">
                    <a class="btn__wix  js-scroll-trigger" href="#about"> 
                        <i class="fa fa-plus" aria-hidden="true"></i>
                        <span>Saber más</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>